code for the linux

mem.c
mutex.c